﻿using MzansiPayrollSystem;

namespace MzansiPayrollSystemTests
{
    // Marks this class as a container for tests.
    [TestClass]
    public sealed class PayrollCalculatorTests
    {
        // An executable test.
        [TestMethod]
        public void CalculateGrossPay_ValidHours_ReturnsCorrectResult()
        {
            // Arrange
            PayrollCalculator calculator = new PayrollCalculator();

            // Known value
            decimal hoursWorked = 40m;

            // Expected value - manually calculated: 40 hours * 950 per hour
            decimal expectedGrossPay = 38000m;

            // Actual value - method output
            decimal actualGrossPay = calculator.CalculateGrossPay(hoursWorked);

            // Assert
            Assert.AreEqual(expectedGrossPay, actualGrossPay);
        }

        [TestMethod]
        public void CalculateUIF_ValidGrossPay_ReturnsCorrectResult() 
        {
            // Arrange
            PayrollCalculator calculator = new PayrollCalculator();

            // Known value
            decimal grossPay = 38000m;

            // Expected value - manually calculated: UIF is 1% of gross pay
            decimal expectedUIF = 380m;

            // Actual value - method output
            decimal actualUIF = calculator.CalculateUIF(grossPay);

            // Assert
            Assert.AreEqual(expectedUIF, actualUIF);
        }

        [TestMethod]
        public void CalculateMembershipFee_ValidGrossPay_ReturnsCorrectResult()
        {
            // Arrange
            PayrollCalculator calculator = new PayrollCalculator();

            // Known value
            decimal grossPay = 38000m;

            // Expected value - manually calculated: Membership fee is 13% of gross pay
            decimal expectedMembershipFee = 4940m;

            // Actual value - method output
            decimal actualMembershipFee = calculator.CalculateMembershipFee(grossPay);

            // Assert
            Assert.AreEqual(expectedMembershipFee, actualMembershipFee);
        }

        [TestMethod]
        public void CalculatePAYE_ValidGrossAndDependents_ReturnsCorrectResult() 
        {
            // Arrange
            PayrollCalculator calculator = new PayrollCalculator();

            // Known values
            decimal grossPay = 38000m;
            int dependents = 2;

            // Expected value - manually calculated
            decimal expectedPAYE = 8407.50m;

            // Actual value - method output
            decimal actualPAYE = calculator.CalculatePAYE(grossPay, dependents);

            // Assert
            Assert.AreEqual(expectedPAYE, actualPAYE);
        }

        [TestMethod]
        public void CalculateTotalDeductions_ValidUifPayeMembershipFee_ReturnsCorrectResult()
        {
            // Arrange
            PayrollCalculator calculator = new PayrollCalculator();

            // Known values
            decimal uif = 380m;
            decimal paye = 8550m;
            decimal membershipFee = 760m;

            // Expected value - manually calculated: Total Deductions = uif + paye + membershipFee
            decimal totalDeductions = uif + paye + membershipFee;

            // Actual value - method output
            decimal actualTotalDeductions = calculator.CalculateTotalDeductions(uif, paye, membershipFee);

            // Assert
            Assert.AreEqual(totalDeductions, actualTotalDeductions);

        }

        [TestMethod]
        public void CalculateNetPay_ValidGrossPayAndTotDeductions_ReturnsCorrectResult() 
        { 
            // Arrange 
            PayrollCalculator calculator = new PayrollCalculator();

            // Known values
            decimal grossPay = 38000m;
            decimal totalDeductions = 9690m;

            // Expected value - manually calculated
            decimal expectedNetPay = grossPay - totalDeductions;

            // Actual value - method output
            decimal actualNetPay = calculator.CalculateNetPay(grossPay, totalDeductions);

            // Assert
            Assert.AreEqual(expectedNetPay, actualNetPay);
        }
    }
}
