﻿namespace MzansiPayrollSystem
{
    partial class FrmPayroll
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHeader = new System.Windows.Forms.Label();
            this.gpbContractorDetails = new System.Windows.Forms.GroupBox();
            this.txtNumOfDependencies = new System.Windows.Forms.TextBox();
            this.lblNumOfDependencies = new System.Windows.Forms.Label();
            this.txtHoursWorked = new System.Windows.Forms.TextBox();
            this.lblHoursWorked = new System.Windows.Forms.Label();
            this.txtContractorName = new System.Windows.Forms.TextBox();
            this.lblContractorName = new System.Windows.Forms.Label();
            this.gpbPayrollResults = new System.Windows.Forms.GroupBox();
            this.txtNetPay = new System.Windows.Forms.TextBox();
            this.lblNetPay = new System.Windows.Forms.Label();
            this.txtTotalDeductions = new System.Windows.Forms.TextBox();
            this.lblTotalDeductions = new System.Windows.Forms.Label();
            this.txtMembershipFee = new System.Windows.Forms.TextBox();
            this.lblMembershipFee = new System.Windows.Forms.Label();
            this.txtUIFDeduction = new System.Windows.Forms.TextBox();
            this.lblUIFDeduction = new System.Windows.Forms.Label();
            this.txtPAYEDeduction = new System.Windows.Forms.TextBox();
            this.lblPAYEDeduction = new System.Windows.Forms.Label();
            this.txtGrossPay = new System.Windows.Forms.TextBox();
            this.lblGrossPay = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.gpbContractorDetails.SuspendLayout();
            this.gpbPayrollResults.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Copperplate Gothic Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.ForeColor = System.Drawing.Color.White;
            this.lblHeader.Location = new System.Drawing.Point(133, 9);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(504, 37);
            this.lblHeader.TabIndex = 0;
            this.lblHeader.Text = "Mzansi Tech Contractors";
            // 
            // gpbContractorDetails
            // 
            this.gpbContractorDetails.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.gpbContractorDetails.Controls.Add(this.txtNumOfDependencies);
            this.gpbContractorDetails.Controls.Add(this.lblNumOfDependencies);
            this.gpbContractorDetails.Controls.Add(this.txtHoursWorked);
            this.gpbContractorDetails.Controls.Add(this.lblHoursWorked);
            this.gpbContractorDetails.Controls.Add(this.txtContractorName);
            this.gpbContractorDetails.Controls.Add(this.lblContractorName);
            this.gpbContractorDetails.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbContractorDetails.Location = new System.Drawing.Point(12, 62);
            this.gpbContractorDetails.Name = "gpbContractorDetails";
            this.gpbContractorDetails.Size = new System.Drawing.Size(350, 350);
            this.gpbContractorDetails.TabIndex = 1;
            this.gpbContractorDetails.TabStop = false;
            this.gpbContractorDetails.Text = "Contractor";
            // 
            // txtNumOfDependencies
            // 
            this.txtNumOfDependencies.Location = new System.Drawing.Point(6, 269);
            this.txtNumOfDependencies.Name = "txtNumOfDependencies";
            this.txtNumOfDependencies.Size = new System.Drawing.Size(334, 32);
            this.txtNumOfDependencies.TabIndex = 5;
            // 
            // lblNumOfDependencies
            // 
            this.lblNumOfDependencies.AutoSize = true;
            this.lblNumOfDependencies.Location = new System.Drawing.Point(6, 242);
            this.lblNumOfDependencies.Name = "lblNumOfDependencies";
            this.lblNumOfDependencies.Size = new System.Drawing.Size(229, 24);
            this.lblNumOfDependencies.TabIndex = 4;
            this.lblNumOfDependencies.Text = "Number of Dependencies:";
            // 
            // txtHoursWorked
            // 
            this.txtHoursWorked.Location = new System.Drawing.Point(6, 161);
            this.txtHoursWorked.Name = "txtHoursWorked";
            this.txtHoursWorked.Size = new System.Drawing.Size(334, 32);
            this.txtHoursWorked.TabIndex = 3;
            // 
            // lblHoursWorked
            // 
            this.lblHoursWorked.AutoSize = true;
            this.lblHoursWorked.Location = new System.Drawing.Point(6, 134);
            this.lblHoursWorked.Name = "lblHoursWorked";
            this.lblHoursWorked.Size = new System.Drawing.Size(136, 24);
            this.lblHoursWorked.TabIndex = 2;
            this.lblHoursWorked.Text = "Hours Worked:";
            // 
            // txtContractorName
            // 
            this.txtContractorName.Location = new System.Drawing.Point(6, 55);
            this.txtContractorName.Name = "txtContractorName";
            this.txtContractorName.Size = new System.Drawing.Size(334, 32);
            this.txtContractorName.TabIndex = 1;
            // 
            // lblContractorName
            // 
            this.lblContractorName.AutoSize = true;
            this.lblContractorName.Location = new System.Drawing.Point(6, 28);
            this.lblContractorName.Name = "lblContractorName";
            this.lblContractorName.Size = new System.Drawing.Size(160, 24);
            this.lblContractorName.TabIndex = 0;
            this.lblContractorName.Text = "Contractor Name:";
            // 
            // gpbPayrollResults
            // 
            this.gpbPayrollResults.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.gpbPayrollResults.Controls.Add(this.txtNetPay);
            this.gpbPayrollResults.Controls.Add(this.lblNetPay);
            this.gpbPayrollResults.Controls.Add(this.txtTotalDeductions);
            this.gpbPayrollResults.Controls.Add(this.lblTotalDeductions);
            this.gpbPayrollResults.Controls.Add(this.txtMembershipFee);
            this.gpbPayrollResults.Controls.Add(this.lblMembershipFee);
            this.gpbPayrollResults.Controls.Add(this.txtUIFDeduction);
            this.gpbPayrollResults.Controls.Add(this.lblUIFDeduction);
            this.gpbPayrollResults.Controls.Add(this.txtPAYEDeduction);
            this.gpbPayrollResults.Controls.Add(this.lblPAYEDeduction);
            this.gpbPayrollResults.Controls.Add(this.txtGrossPay);
            this.gpbPayrollResults.Controls.Add(this.lblGrossPay);
            this.gpbPayrollResults.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbPayrollResults.Location = new System.Drawing.Point(420, 62);
            this.gpbPayrollResults.Name = "gpbPayrollResults";
            this.gpbPayrollResults.Size = new System.Drawing.Size(350, 430);
            this.gpbPayrollResults.TabIndex = 2;
            this.gpbPayrollResults.TabStop = false;
            this.gpbPayrollResults.Text = "Payroll Results";
            // 
            // txtNetPay
            // 
            this.txtNetPay.Location = new System.Drawing.Point(6, 386);
            this.txtNetPay.Name = "txtNetPay";
            this.txtNetPay.Size = new System.Drawing.Size(338, 32);
            this.txtNetPay.TabIndex = 11;
            // 
            // lblNetPay
            // 
            this.lblNetPay.AutoSize = true;
            this.lblNetPay.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNetPay.Location = new System.Drawing.Point(6, 361);
            this.lblNetPay.Name = "lblNetPay";
            this.lblNetPay.Size = new System.Drawing.Size(74, 22);
            this.lblNetPay.TabIndex = 10;
            this.lblNetPay.Text = "Net Pay:";
            // 
            // txtTotalDeductions
            // 
            this.txtTotalDeductions.Location = new System.Drawing.Point(6, 319);
            this.txtTotalDeductions.Name = "txtTotalDeductions";
            this.txtTotalDeductions.ReadOnly = true;
            this.txtTotalDeductions.Size = new System.Drawing.Size(338, 32);
            this.txtTotalDeductions.TabIndex = 9;
            // 
            // lblTotalDeductions
            // 
            this.lblTotalDeductions.AutoSize = true;
            this.lblTotalDeductions.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalDeductions.Location = new System.Drawing.Point(6, 295);
            this.lblTotalDeductions.Name = "lblTotalDeductions";
            this.lblTotalDeductions.Size = new System.Drawing.Size(141, 22);
            this.lblTotalDeductions.TabIndex = 8;
            this.lblTotalDeductions.Text = "Total Deductions:";
            // 
            // txtMembershipFee
            // 
            this.txtMembershipFee.Location = new System.Drawing.Point(6, 252);
            this.txtMembershipFee.Name = "txtMembershipFee";
            this.txtMembershipFee.ReadOnly = true;
            this.txtMembershipFee.Size = new System.Drawing.Size(338, 32);
            this.txtMembershipFee.TabIndex = 7;
            // 
            // lblMembershipFee
            // 
            this.lblMembershipFee.AutoSize = true;
            this.lblMembershipFee.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMembershipFee.Location = new System.Drawing.Point(6, 228);
            this.lblMembershipFee.Name = "lblMembershipFee";
            this.lblMembershipFee.Size = new System.Drawing.Size(141, 22);
            this.lblMembershipFee.TabIndex = 6;
            this.lblMembershipFee.Text = "Membership Fee:";
            // 
            // txtUIFDeduction
            // 
            this.txtUIFDeduction.Location = new System.Drawing.Point(6, 185);
            this.txtUIFDeduction.Name = "txtUIFDeduction";
            this.txtUIFDeduction.ReadOnly = true;
            this.txtUIFDeduction.Size = new System.Drawing.Size(338, 32);
            this.txtUIFDeduction.TabIndex = 5;
            // 
            // lblUIFDeduction
            // 
            this.lblUIFDeduction.AutoSize = true;
            this.lblUIFDeduction.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUIFDeduction.Location = new System.Drawing.Point(6, 161);
            this.lblUIFDeduction.Name = "lblUIFDeduction";
            this.lblUIFDeduction.Size = new System.Drawing.Size(123, 22);
            this.lblUIFDeduction.TabIndex = 4;
            this.lblUIFDeduction.Text = "UIF Deduction:";
            // 
            // txtPAYEDeduction
            // 
            this.txtPAYEDeduction.Location = new System.Drawing.Point(6, 119);
            this.txtPAYEDeduction.Name = "txtPAYEDeduction";
            this.txtPAYEDeduction.ReadOnly = true;
            this.txtPAYEDeduction.Size = new System.Drawing.Size(338, 32);
            this.txtPAYEDeduction.TabIndex = 3;
            // 
            // lblPAYEDeduction
            // 
            this.lblPAYEDeduction.AutoSize = true;
            this.lblPAYEDeduction.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPAYEDeduction.Location = new System.Drawing.Point(6, 95);
            this.lblPAYEDeduction.Name = "lblPAYEDeduction";
            this.lblPAYEDeduction.Size = new System.Drawing.Size(135, 22);
            this.lblPAYEDeduction.TabIndex = 2;
            this.lblPAYEDeduction.Text = "PAYE Deduction:";
            // 
            // txtGrossPay
            // 
            this.txtGrossPay.Location = new System.Drawing.Point(6, 52);
            this.txtGrossPay.Name = "txtGrossPay";
            this.txtGrossPay.ReadOnly = true;
            this.txtGrossPay.Size = new System.Drawing.Size(338, 32);
            this.txtGrossPay.TabIndex = 1;
            // 
            // lblGrossPay
            // 
            this.lblGrossPay.AutoSize = true;
            this.lblGrossPay.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrossPay.Location = new System.Drawing.Point(6, 28);
            this.lblGrossPay.Name = "lblGrossPay";
            this.lblGrossPay.Size = new System.Drawing.Size(88, 22);
            this.lblGrossPay.TabIndex = 0;
            this.lblGrossPay.Text = "Gross Pay:";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculate.Location = new System.Drawing.Point(12, 423);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(110, 40);
            this.btnCalculate.TabIndex = 3;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnReset
            // 
            this.btnReset.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(142, 423);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(100, 40);
            this.btnReset.TabIndex = 4;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(262, 423);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 40);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // FrmPayroll
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.ClientSize = new System.Drawing.Size(782, 503);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.gpbPayrollResults);
            this.Controls.Add(this.gpbContractorDetails);
            this.Controls.Add(this.lblHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmPayroll";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mzansi Tech Contractors Payroll System";
            this.gpbContractorDetails.ResumeLayout(false);
            this.gpbContractorDetails.PerformLayout();
            this.gpbPayrollResults.ResumeLayout(false);
            this.gpbPayrollResults.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.GroupBox gpbContractorDetails;
        private System.Windows.Forms.GroupBox gpbPayrollResults;
        private System.Windows.Forms.Label lblNumOfDependencies;
        private System.Windows.Forms.TextBox txtHoursWorked;
        private System.Windows.Forms.Label lblHoursWorked;
        private System.Windows.Forms.TextBox txtContractorName;
        private System.Windows.Forms.Label lblContractorName;
        private System.Windows.Forms.TextBox txtNumOfDependencies;
        private System.Windows.Forms.TextBox txtGrossPay;
        private System.Windows.Forms.Label lblGrossPay;
        private System.Windows.Forms.TextBox txtUIFDeduction;
        private System.Windows.Forms.Label lblUIFDeduction;
        private System.Windows.Forms.TextBox txtPAYEDeduction;
        private System.Windows.Forms.Label lblPAYEDeduction;
        private System.Windows.Forms.TextBox txtTotalDeductions;
        private System.Windows.Forms.Label lblTotalDeductions;
        private System.Windows.Forms.TextBox txtMembershipFee;
        private System.Windows.Forms.Label lblMembershipFee;
        private System.Windows.Forms.Label lblNetPay;
        private System.Windows.Forms.TextBox txtNetPay;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
    }
}

