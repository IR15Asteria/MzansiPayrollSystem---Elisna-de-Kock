﻿using System.Windows.Forms;

namespace MzansiPayrollSystem
{
    public partial class FrmPayroll : Form
    {
        public FrmPayroll()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, System.EventArgs e)
        {
            // Create an instance of the PayrollCalculator class to perform calculations.
            PayrollCalculator calculator = new PayrollCalculator();

            // Validation and input:
            // =====================================================================================================================================
            // This validates that txtContractorName is not empty and does not contain whitespace.
            if (string.IsNullOrWhiteSpace(txtContractorName.Text)){
                // A messagebox is used to display a user-friendly error message in the case that validation fails.
                MessageBox.Show("Please enter a name for the contractor.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Focus is set back to field that requires a value.
                txtContractorName.Focus();
                // This is used to exit the method early.
                return;
            }

            if (string.IsNullOrWhiteSpace(txtHoursWorked.Text) || !decimal.TryParse(txtHoursWorked.Text, out decimal hoursWorked) || hoursWorked < 0)
            {
                MessageBox.Show("Please enter a valid, numeric value of hours worked.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtHoursWorked.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtNumOfDependencies.Text) || !int.TryParse(txtNumOfDependencies.Text, out int dependents) || dependents < 0 || dependents > 10)
            {
                MessageBox.Show("Please enter a valid number of dependencies (0-10).", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNumOfDependencies.Focus();
                return;
            }

            // Processing:
            // =====================================================================================================================================
            // Then, call the appropriate methods of the Payroll class to compute the required outputs.
            decimal grossPay = calculator.CalculateGrossPay(hoursWorked);

            decimal paye = calculator.CalculatePAYE(grossPay, dependents);

            decimal uif = calculator.CalculateUIF(grossPay);

            decimal membershipFee = calculator.CalculateMembershipFee(grossPay);

            decimal totalDeductions = calculator.CalculateTotalDeductions(uif, paye, membershipFee);

            decimal netPay = calculator.CalculateNetPay(grossPay, totalDeductions);

            // Ouputs:
            // =====================================================================================================================================
            // Display the calculated results in the appropriate textbox.
            txtGrossPay.Text = grossPay.ToString("C");
            txtPAYEDeduction.Text = paye.ToString("C");
            txtUIFDeduction.Text = uif.ToString("C");
            txtMembershipFee.Text = membershipFee.ToString("C");
            txtTotalDeductions.Text = totalDeductions.ToString("C");
            txtNetPay.Text = netPay.ToString("C");
        }

        // This method intends to handle the logic for resetting the form's input and output fields when the "Reset" button is clicked.
        private void btnReset_Click(object sender, System.EventArgs e)
        {
            // Clear all textfields for the contractor groupbox.
            txtContractorName.Clear();
            txtHoursWorked.Clear();
            txtNumOfDependencies.Clear();

            // Clear all fields for the payroll results groupbox.
            txtGrossPay.Clear();
            txtPAYEDeduction.Clear();
            txtUIFDeduction.Clear();
            txtMembershipFee.Clear();
            txtTotalDeductions.Clear();
            txtNetPay.Clear();

            // Set focus to the first textfield, txtContractorName.
            txtContractorName.Focus();
        }

        // This method is responsible for handling the logic to exit the application when the "Exit" button is clicked.
        private void btnExit_Click(object sender, System.EventArgs e)
        {
            Application.Exit();
        }
    }
}
