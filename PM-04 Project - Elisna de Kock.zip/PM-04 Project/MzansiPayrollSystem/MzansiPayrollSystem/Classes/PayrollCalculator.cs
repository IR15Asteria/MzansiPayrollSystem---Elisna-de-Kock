﻿namespace MzansiPayrollSystem
{
    // This class handles all calculations for an employee's payroll based on hours worked and hourly rate.
    public class PayrollCalculator
    {
        // Creating a const variable for hourly_rate to improve readability of the code later on.
        // m - means it's a decimal literal (without it C# assumes it's a double).
        private const decimal HOURLY_RATE = 950m;

        // Number 1: Calculate the gross pay for an employee based on hours worked and hourly rate.
        public decimal CalculateGrossPay(decimal hoursWorked)
        {
            return hoursWorked * HOURLY_RATE;
        }

        // Number 2: Calculate the PAYE which is 25% of the gross pay.
        public decimal CalculatePAYE(decimal grossPay, int dependents)
        {
            // 5.75% reduction per dependent
            decimal dependentReduction = (grossPay - (grossPay * 0.0575m * dependents)) * 0.25m;
            return dependentReduction;
        }

        // Number 3: Calculate the UIF which is 1% of the gross pay.
        public decimal CalculateUIF(decimal grossPay) 
        {
            return grossPay * 0.01m;
        }

        // Number 4: Calculate the Membership fee which is 13% of the gross pay.
        public decimal CalculateMembershipFee(decimal grossPay)
        {
            return grossPay * 0.13m;
        }

        // Number 5: Calculate the total deductions which is the sum of UIF and Membership fee.
        public decimal CalculateTotalDeductions(decimal uif, decimal paye, decimal membershipFee)
        {
            return uif + paye + membershipFee;
        }

        // Number 6: Calculate the net pay which is the gross pay minus total deductions.
        public decimal CalculateNetPay(decimal grossPay, decimal totalDeductions)
        {
            return grossPay - totalDeductions;
        }
    }
}